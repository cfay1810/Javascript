var myDOMAccess = {

// Create an init() method of our myDOMAccess custom object
init:function(){
//Replace an image(image rollover)
var soldierPic = document.getElementById('pic');

soldierPic.setAttribute('src', 'images/pics/bavLine.png');

//Create div#imageTabs using setAttribute() method to set the 'id' attribute
//create element needs an html tag in the ()
var imageTabsDiv = document.createElement('div');

imageTabsDiv.setAttribute('id', "imageTabs");

//Store the reference to div#imageTabs in a variable named imageTabsDiv
//imageTabsDiv.id = 'imageTabs';

//Create four images from src images/pics folder
//
//Store the references to the new image elements
var tab01 = document.createElement('img');
tab01.src = 'images/pics/imageTab01.png';
imageTabsDiv.appendChild(tab01);
var br01 = document.createElement('br');
imageTabsDiv.appendChild(br01);

var tab02 = document.createElement('img');
tab02.src = 'images/pics/imageTab02.png';
imageTabsDiv.appendChild(tab02);
var br02 = document.createElement('br');
imageTabsDiv.appendChild(br02);

var tab03 = document.createElement('img');
tab03.src = 'images/pics/imageTab03.png';
imageTabsDiv.appendChild(tab03);
var br03 = document.createElement('br');
imageTabsDiv.appendChild(br03);

var tab04 = document.createElement('img');
tab04.src = 'images/pics/imageTab04.png';
imageTabsDiv.appendChild(tab04);


// Get a reference to div#primaryPic and name it primaryPic
var primaryPic = document.getElementById('primaryPic');

//Add div#imagetabs as a child of div#primarypic
primaryPic.appendChild(imageTabsDiv);

//Position div#imageTabs as ashown in the video using abosolute positioning
imageTabsDiv.style.position = 'absolute';
imageTabsDiv.style.left = '-25px';
imageTabsDiv.style.top = '10px';

// ****************************************************************
//
// Replace the polaroid image with the images/navPhotos/theArt_polaroidSmall.png
//
// ****************************************************************

var polaroid = document.getElementById('defaultTab').getElementsByTagName('img')[0];
//alert(polaroid.nodeName);

polaroid.src = 'images/navPhotos/theArt_polaroidSmall.png';

// Change the styles applied to the <p> tags within div#motd
var motdDiv = document.getElementById('motd');

var pList = motdDiv.getElementsByTagName('p');

//alert(pList.length);

for (i = 0; i < pList.length; i++){
	pList[i].style.background = 'url(images/pBackground.png)';
	pList[i].style.color = '#eee';
	pList[i].style.borderRadius = '6px';
	pList[i].style.padding = '2px';
	pList[i].style.textShadow = '#000 3px 3px 3px';//look up text shadow
}

// Change the copyright symbol "2012 Jon Cooley" text into copyright symbol
// "2012 Yournamehere" where "Yournamehere" should be an email link to
// your email address (replace "Yournamehere" with your name :-)

var copyRight = document.getElementById('copyRight');

var emailAddress = document.createElement('a');

emailAddress.setAttribute('href','mailto:chelseyfay1810@gmail.com');

var emailText = document.createTextNode('Chelsey Fay');
emailAddress.appendChild(emailText);

//change the content of the copyright span tag using the innerHTML tag
copyRight.innerHTML = '&copy; 2015 ';

copyRight.appendChild(emailAddress);

	}

};

//Run myDOMAcess.init() when the web page's content has finished loading

Core.start(myDOMAccess);
